# Gym Web (Next.js)

## Setup

PowerShell:

```
cd gym_web
npm i
$env:NEXT_PUBLIC_API_BASE="http://localhost:8000/api"
npm run dev
```

- Members list: `/`
- New member: `/members/new`













