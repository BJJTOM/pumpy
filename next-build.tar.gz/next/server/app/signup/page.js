(()=>{var e={};e.id=4966,e.ids=[4966],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},9491:e=>{"use strict";e.exports=require("assert")},6113:e=>{"use strict";e.exports=require("crypto")},2361:e=>{"use strict";e.exports=require("events")},7147:e=>{"use strict";e.exports=require("fs")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},2037:e=>{"use strict";e.exports=require("os")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},6224:e=>{"use strict";e.exports=require("tty")},7310:e=>{"use strict";e.exports=require("url")},3837:e=>{"use strict";e.exports=require("util")},9796:e=>{"use strict";e.exports=require("zlib")},3531:(e,s,a)=>{"use strict";a.r(s),a.d(s,{GlobalError:()=>l.a,__next_app__:()=>p,originalPathname:()=>x,pages:()=>o,routeModule:()=>m,tree:()=>c}),a(9791),a(1506),a(5866);var t=a(3191),r=a(8716),d=a(7922),l=a.n(d),n=a(5231),i={};for(let e in n)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(i[e]=()=>n[e]);a.d(s,i);let c=["",{children:["signup",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,9791)),"C:\\Users\\guddn\\Downloads\\COCO\\gym_web\\app\\signup\\page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,1506)),"C:\\Users\\guddn\\Downloads\\COCO\\gym_web\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,5866,23)),"next/dist/client/components/not-found-error"]}],o=["C:\\Users\\guddn\\Downloads\\COCO\\gym_web\\app\\signup\\page.tsx"],x="/signup/page",p={require:a,loadChunk:()=>Promise.resolve()},m=new t.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/signup/page",pathname:"/signup",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},1238:(e,s,a)=>{Promise.resolve().then(a.bind(a,5309))},5309:(e,s,a)=>{"use strict";a.r(s),a.d(s,{default:()=>p});var t=a(326),r=a(7626),d=a.n(r),l=a(7577),n=a(5047),i=a(4099);a(7817);let c={terms:{title:"이용 약관",content:`
제1조 (목적)
본 약관은 펌피(이하 "회사")가 제공하는 헬스장 회원 관리 서비스(이하 "서비스")의 이용과 관련하여 회사와 회원 간의 권리, 의무 및 책임사항, 기타 필요한 사항을 규정함을 목적으로 합니다.

제2조 (정의)
1. "서비스"란 회사가 제공하는 모든 헬스장 관련 서비스를 의미합니다.
2. "회원"이란 본 약관에 동의하고 회사와 이용계약을 체결하여 서비스를 이용하는 자를 말합니다.
3. "이용계약"이란 서비스 이용과 관련하여 회사와 회원 간에 체결하는 계약을 말합니다.

제3조 (약관의 게시와 개정)
1. 회사는 본 약관의 내용을 회원이 쉽게 알 수 있도록 서비스 초기 화면에 게시합니다.
2. 회사는 필요한 경우 관련 법령을 위배하지 않는 범위에서 본 약관을 개정할 수 있습니다.
3. 회사가 약관을 개정할 경우에는 적용일자 및 개정사유를 명시하여 현행약관과 함께 서비스 초기화면에 그 적용일자 7일 이전부터 적용일자 전일까지 공지합니다.

제4조 (서비스의 제공 및 변경)
1. 회사는 다음과 같은 서비스를 제공합니다:
   - 헬스장 시설 이용 서비스
   - 운동 프로그램 제공
   - 개인 트레이닝 서비스
   - 락커 이용 서비스
   - 기타 회사가 추가 개발하거나 제휴계약 등을 통해 회원에게 제공하는 일체의 서비스
2. 회사는 상당한 이유가 있는 경우 서비스의 내용을 변경할 수 있으며, 변경 내용은 사전에 공지합니다.

제5조 (서비스 이용시간)
1. 서비스 이용은 회사의 업무상 또는 기술상 특별한 지장이 없는 한 연중무휴, 1일 24시간 제공함을 원칙으로 합니다.
2. 회사는 시스템 정기점검, 증설 및 교체를 위해 회사가 정한 날이나 시간에 서비스를 일시 중단할 수 있으며, 예정된 작업으로 인한 서비스 일시 중단은 사전에 공지합니다.

제6조 (회원의 의무)
1. 회원은 다음 행위를 하여서는 안 됩니다:
   - 신청 또는 변경 시 허위내용의 등록
   - 타인의 정보 도용
   - 회사가 게시한 정보의 변경
   - 회사가 정한 정보 이외의 정보(컴퓨터 프로그램 등) 등의 송신 또는 게시
   - 회사와 기타 제3자의 저작권 등 지적재산권에 대한 침해
   - 회사 및 기타 제3자의 명예를 손상시키거나 업무를 방해하는 행위
   - 외설 또는 폭력적인 메시지, 화상, 음성, 기타 공서양속에 반하는 정보를 서비스에 공개 또는 게시하는 행위

제7조 (회원탈퇴 및 자격 상실 등)
1. 회원은 회사에 언제든지 탈퇴를 요청할 수 있으며, 회사는 즉시 회원탈퇴를 처리합니다.
2. 회원이 다음 각호의 사유에 해당하는 경우, 회사는 회원자격을 제한 및 정지시킬 수 있습니다:
   - 가입 신청 시에 허위 내용을 등록한 경우
   - 다른 사람의 서비스 이용을 방해하거나 그 정보를 도용하는 등 전자상거래 질서를 위협하는 경우
   - 서비스를 이용하여 법령 또는 본 약관이 금지하거나 공서양속에 반하는 행위를 하는 경우

제8조 (환불 규정)
1. 회원이 회원권 구매 후 환불을 요청할 경우, 다음과 같이 처리합니다:
   - 이용 시작 전: 전액 환불
   - 이용 기간의 1/3 경과 전: 결제금액의 2/3 환불
   - 이용 기간의 1/2 경과 전: 결제금액의 1/2 환불
   - 이용 기간의 1/2 경과 후: 환불 불가

제9조 (면책조항)
1. 회사는 천재지변 또는 이에 준하는 불가항력으로 인하여 서비스를 제공할 수 없는 경우에는 서비스 제공에 관한 책임이 면제됩니다.
2. 회사는 회원의 귀책사유로 인한 서비스 이용의 장애에 대하여는 책임을 지지 않습니다.

제10조 (분쟁해결)
1. 회사는 회원이 제기하는 정당한 의견이나 불만을 반영하고 그 피해를 보상처리하기 위하여 피해보상처리기구를 설치\xb7운영합니다.
2. 본 약관에서 정하지 아니한 사항과 본 약관의 해석에 관하여는 관련법령 또는 상관례에 따릅니다.

부칙
본 약관은 2025년 1월 1일부터 시행합니다.
    `},privacy:{title:"개인정보 처리방침",content:`
펌피(이하 "회사")는 「개인정보 보호법」 제30조에 따라 정보주체의 개인정보를 보호하고 이와 관련한 고충을 신속하고 원활하게 처리할 수 있도록 하기 위하여 다음과 같이 개인정보 처리방침을 수립\xb7공개합니다.

제1조 (개인정보의 처리 목적)
회사는 다음의 목적을 위하여 개인정보를 처리합니다. 처리하고 있는 개인정보는 다음의 목적 이외의 용도로는 이용되지 않으며, 이용 목적이 변경되는 경우에는 「개인정보 보호법」 제18조에 따라 별도의 동의를 받는 등 필요한 조치를 이행할 예정입니다.

1. 회원 가입 및 관리
   - 회원 가입의사 확인, 회원제 서비스 제공에 따른 본인 식별\xb7인증, 회원자격 유지\xb7관리, 서비스 부정이용 방지, 각종 고지\xb7통지 목적으로 개인정보를 처리합니다.

2. 서비스 제공
   - 헬스장 시설 이용, 운동 프로그램 제공, 개인 트레이닝, 락커 배정, 출입 관리를 목적으로 개인정보를 처리합니다.

3. 마케팅 및 광고에의 활용
   - 신규 서비스(제품) 개발 및 맞춤 서비스 제공, 이벤트 및 광고성 정보 제공 및 참여기회 제공 등을 목적으로 개인정보를 처리합니다.

제2조 (개인정보의 처리 및 보유 기간)
1. 회사는 법령에 따른 개인정보 보유\xb7이용기간 또는 정보주체로부터 개인정보를 수집 시에 동의받은 개인정보 보유\xb7이용기간 내에서 개인정보를 처리\xb7보유합니다.
2. 각각의 개인정보 처리 및 보유 기간은 다음과 같습니다:
   - 회원 가입 및 관리: 회원 탈퇴 시까지 (단, 관계 법령 위반에 따른 수사\xb7조사 등이 진행 중인 경우에는 해당 수사\xb7조사 종료 시까지)
   - 계약\xb7청약철회 등에 관한 기록: 5년
   - 대금결제 및 재화 등의 공급에 관한 기록: 5년
   - 소비자의 불만 또는 분쟁처리에 관한 기록: 3년

제3조 (처리하는 개인정보의 항목)
회사는 다음의 개인정보 항목을 처리하고 있습니다:

1. 필수항목
   - 성명, 생년월일, 성별, 연락처(전화번호, 휴대전화번호), 주소, 이메일

2. 선택항목
   - 긴급연락처, 건강 정보(지병, 알레르기 등), 프로필 사진

3. 자동 수집 항목
   - 서비스 이용기록, 접속 로그, 쿠키, 접속 IP 정보, 결제기록, 출입기록

제4조 (개인정보의 제3자 제공)
회사는 정보주체의 개인정보를 제1조(개인정보의 처리 목적)에서 명시한 범위 내에서만 처리하며, 정보주체의 동의, 법률의 특별한 규정 등 「개인정보 보호법」 제17조 및 제18조에 해당하는 경우에만 개인정보를 제3자에게 제공합니다.

제5조 (개인정보처리의 위탁)
회사는 원활한 개인정보 업무처리를 위하여 다음과 같이 개인정보 처리업무를 위탁하고 있습니다:
- 결제 처리 업체: 결제 대행 서비스
- SMS 발송 업체: 문자 메시지 발송

제6조 (정보주체의 권리\xb7의무 및 그 행사방법)
1. 정보주체는 회사에 대해 언제든지 다음 각 호의 개인정보 보호 관련 권리를 행사할 수 있습니다:
   - 개인정보 열람 요구
   - 오류 등이 있을 경우 정정 요구
   - 삭제 요구
   - 처리정지 요구

2. 제1항에 따른 권리 행사는 회사에 대해 「개인정보 보호법」 시행규칙 별지 제8호 서식에 따라 서면, 전자우편 등을 통하여 하실 수 있으며, 회사는 이에 대해 지체 없이 조치하겠습니다.

제7조 (개인정보의 파기)
1. 회사는 개인정보 보유기간의 경과, 처리목적 달성 등 개인정보가 불필요하게 되었을 때에는 지체없이 해당 개인정보를 파기합니다.
2. 개인정보 파기의 절차 및 방법은 다음과 같습니다:
   - 파기절차: 불필요하게 된 개인정보를 선정하고, 회사의 개인정보 보호책임자의 승인을 받아 개인정보를 파기합니다.
   - 파기방법: 전자적 파일 형태의 정보는 기록을 재생할 수 없는 기술적 방법을 사용합니다.

제8조 (개인정보의 안전성 확보 조치)
회사는 개인정보의 안전성 확보를 위해 다음과 같은 조치를 취하고 있습니다:
1. 관리적 조치: 내부관리계획 수립\xb7시행, 정기적 직원 교육 등
2. 기술적 조치: 개인정보처리시스템 등의 접근권한 관리, 접근통제시스템 설치, 고유식별정보 등의 암호화, 보안프로그램 설치
3. 물리적 조치: 전산실, 자료보관실 등의 접근통제

제9조 (개인정보 보호책임자)
회사는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 정보주체의 불만처리 및 피해구제 등을 위하여 아래와 같이 개인정보 보호책임자를 지정하고 있습니다:

- 개인정보 보호책임자
  성명: 김펌피
  직책: 대표
  연락처: 02-1234-5678, pumpy@example.com

제10조 (개인정보 처리방침 변경)
이 개인정보처리방침은 시행일로부터 적용되며, 법령 및 방침에 따른 변경내용의 추가, 삭제 및 정정이 있는 경우에는 변경사항의 시행 7일 전부터 공지사항을 통하여 고지할 것입니다.

부칙
본 방침은 2025년 1월 1일부터 시행합니다.
    `},marketing:{title:"마케팅 정보 수신 및 활용 동의",content:`
펌피(이하 "회사")는 회원님의 소중한 개인정보를 마케팅에 활용하고자 아래와 같이 동의를 구합니다.

제1조 (마케팅 정보 수신 동의)
회사는 회원님께 다양한 혜택 정보 및 이벤트 안내를 위해 마케팅 정보를 발송하고자 합니다.

1. 수신 목적
   - 신규 서비스 및 상품 안내
   - 이벤트 및 프로모션 정보 제공
   - 할인 쿠폰 및 특별 혜택 안내
   - 운동 프로그램 및 클래스 일정 공지
   - 회원 대상 설문조사 및 의견 수렴

2. 수신 방법
   - 이메일(E-mail)
   - 문자메시지(SMS/MMS)
   - 앱 푸시 알림
   - 카카오톡 알림톡

3. 보유 및 이용기간
   - 동의일로부터 회원 탈퇴 시 또는 마케팅 동의 철회 시까지

제2조 (사진 및 영상 촬영\xb7활용 동의)
회사는 헬스장 홍보 및 마케팅을 위해 회원님의 운동 모습을 촬영하고 활용하고자 합니다.

1. 촬영 목적
   - 헬스장 홍보용 사진 및 영상 제작
   - SNS(인스타그램, 페이스북 등) 게시
   - 홈페이지 및 앱 내 콘텐츠 활용
   - 광고 및 마케팅 자료 제작
   - 언론 보도자료 제공

2. 촬영 내용
   - 운동 중인 모습
   - 시설 이용 모습
   - 이벤트 참여 모습
   - 인터뷰 영상

3. 활용 매체
   - 홈페이지 및 모바일 앱
   - SNS (인스타그램, 페이스북, 유튜브 등)
   - 오프라인 인쇄물 (브로슈어, 포스터 등)
   - 언론 매체
   - 온라인 광고

4. 보유 및 이용기간
   - 동의일로부터 회원 탈퇴 시 또는 촬영 동의 철회 시까지
   - 단, 이미 제작되어 배포된 콘텐츠의 경우 즉시 삭제가 어려울 수 있으며, 회수 가능한 범위 내에서 최대한 삭제 조치합니다.

제3조 (개인정보 제공 동의)
마케팅 정보 발송 및 사진\xb7영상 촬영을 위해 다음의 개인정보가 활용됩니다:

1. 필수 항목
   - 성명, 연락처(휴대전화번호, 이메일)

2. 선택 항목
   - 성별, 연령대, 관심 운동 종목
   - 사진 및 영상 속 초상

제4조 (동의 거부권 및 불이익)
1. 회원님은 위 마케팅 정보 수신 및 사진\xb7영상 촬영\xb7활용에 대한 동의를 거부하실 수 있습니다.
2. 다만, 동의를 거부하시는 경우 다음과 같은 불이익이 있을 수 있습니다:
   - 각종 이벤트, 프로모션, 할인 혜택 정보를 받으실 수 없습니다.
   - 회원 대상 특별 프로그램 및 이벤트 참여에 제한이 있을 수 있습니다.
3. 서비스 이용에는 영향이 없으며, 동의 거부 시에도 정상적으로 헬스장 시설을 이용하실 수 있습니다.

제5조 (동의 철회)
1. 회원님은 언제든지 마케팅 정보 수신 및 사진\xb7영상 활용 동의를 철회하실 수 있습니다.
2. 동의 철회 방법:
   - 회원 정보 페이지에서 직접 설정 변경
   - 고객센터 유선 연락 (02-1234-5678)
   - 이메일 문의 (pumpy@example.com)
   - 각 마케팅 메시지 내 '수신거부' 링크 클릭
3. 동의 철회 시 즉시 마케팅 정보 발송이 중단되며, 이미 촬영된 사진\xb7영상은 더 이상 활용되지 않습니다.

제6조 (문의처)
마케팅 정보 수신 및 사진\xb7영상 촬영\xb7활용과 관련하여 궁금하신 사항이 있으시면 아래로 연락 주시기 바랍니다.

- 담당 부서: 마케팅팀
- 연락처: 02-1234-5678
- 이메일: marketing@pumpy.com
- 운영 시간: 평일 09:00 ~ 18:00 (주말 및 공휴일 휴무)

제7조 (SNS 및 커뮤니티 게시물 활용)
1. 회원님이 펌피 앱 내 커뮤니티에 게시한 글, 사진, 영상은 회사의 마케팅 자료로 활용될 수 있습니다.
2. 단, 비공개 설정된 게시물은 활용되지 않습니다.
3. 게시물 활용을 원하지 않으실 경우, 게시 시 비공개로 설정하거나 고객센터로 요청하시면 즉시 삭제 조치합니다.

제8조 (제3자 제공 동의)
1. 회사는 원칙적으로 회원님의 개인정보를 제3자에게 제공하지 않습니다.
2. 다만, 다음의 경우 제3자에게 정보가 제공될 수 있습니다:
   - 제휴 이벤트 진행 시 (사전 동의 필요)
   - 경품 배송을 위한 배송업체 정보 제공
   - 법령에 의해 요구되는 경우

부칙
본 동의서는 2025년 1월 1일부터 시행합니다.

※ 본 마케팅 정보 수신 및 사진\xb7영상 촬영\xb7활용 동의는 선택사항이며, 동의하지 않으셔도 헬스장 서비스 이용에는 제한이 없습니다.
    `}};function o({isOpen:e,onClose:s,type:a}){let[r,d]=(0,l.useState)(!1),n=()=>{d(!0),setTimeout(()=>{d(!1),s()},300)};if(!e&&!r)return null;let i=c[a];return t.jsx("div",{className:`terms-modal-overlay ${r?"closing":""}`,onClick:n,children:(0,t.jsxs)("div",{className:"terms-modal-container",onClick:e=>e.stopPropagation(),children:[(0,t.jsxs)("div",{className:"terms-modal-header",children:[t.jsx("h2",{children:i.title}),t.jsx("button",{className:"terms-modal-close",onClick:n,children:t.jsx("svg",{width:"24",height:"24",viewBox:"0 0 24 24",fill:"none",children:t.jsx("path",{d:"M18 6L6 18M6 6L18 18",stroke:"currentColor",strokeWidth:"2",strokeLinecap:"round"})})})]}),t.jsx("div",{className:"terms-modal-content",children:t.jsx("pre",{children:i.content})}),t.jsx("div",{className:"terms-modal-footer",children:t.jsx("button",{className:"terms-modal-confirm",onClick:n,children:"확인"})})]})})}var x=a(6824);function p(){let e=(0,n.useRouter)(),[s,a]=(0,l.useState)(1),[r,c]=(0,l.useState)({first_name:"",last_name:"",phone:"",email:"",password:"",password_confirm:"",birth_date:"",gender:"",address:"",emergency_contact:"",emergency_contact_relation:"",height:"",weight:"",blood_type:"",medical_notes:"",current_level:"초보",age_group:"일반부",religion:"무교",notes:"",referrer_code:""}),[p,m]=(0,l.useState)({terms:!1,privacy:!1,marketing:!1}),[g,j]=(0,l.useState)(null),[u,h]=(0,l.useState)(!1),b=(e,s)=>{c(a=>({...a,[e]:s}))},f=()=>r.first_name&&r.last_name?r.phone?r.email?!r.password||r.password.length<6?(alert("❌ 비밀번호는 최소 6자 이상이어야 합니다."),!1):r.password===r.password_confirm||(alert("❌ 비밀번호가 일치하지 않습니다."),!1):(alert("❌ 이메일을 입력해주세요."),!1):(alert("❌ 전화번호를 입력해주세요."),!1):(alert("❌ 이름을 입력해주세요."),!1),v=()=>r.birth_date?!!r.gender||(alert("❌ 성별을 선택해주세요."),!1):(alert("❌ 생년월일을 입력해주세요."),!1),y=()=>!!p.terms&&!!p.privacy||(alert("❌ 필수 약관에 동의해주세요."),!1),N=()=>{(1!==s||f())&&(2!==s||v())&&a(e=>e+1)},_=()=>{a(e=>e-1)},C=async s=>{if(s.preventDefault(),y()){h(!0);try{let s={first_name:r.first_name,last_name:r.last_name,phone:r.phone,email:r.email,password:r.password,birth_date:r.birth_date||null,gender:r.gender||"",address:r.address||"",emergency_contact:r.emergency_contact||"",emergency_contact_relation:r.emergency_contact_relation||"",height:r.height?parseFloat(r.height):null,weight:r.weight?parseFloat(r.weight):null,blood_type:r.blood_type||"",medical_notes:r.medical_notes||"",current_level:r.current_level||"초보",age_group:r.age_group||"일반부",religion:r.religion||"무교",notes:r.notes||"",status:"pending",phone_verified:!1,email_verified:!1,terms_agreed:p.terms,privacy_agreed:p.privacy,marketing_agreed:p.marketing,terms_agreed_date:p.terms?new Date().toISOString():null,privacy_agreed_date:p.privacy?new Date().toISOString():null,marketing_agreed_date:p.marketing?new Date().toISOString():null,join_date:new Date().toISOString().split("T")[0]},a=(0,x.kG)();console.log("회원 신청 데이터:",s);let t=await i.Z.post(`${a}/members/`,s);console.log("회원 신청 성공:",t.data),localStorage.setItem("pendingUser",JSON.stringify({...t.data,email:r.email,password:r.password})),alert(`✅ 회원 신청이 완료되었습니다!

회원번호: ${t.data.id}

관리자 승인 후 로그인하실 수 있습니다.`),e.push("/auth/login")}catch(e){console.error("회원 신청 실패:",e),alert("❌ 회원 신청 실패: "+(e.response?.data?.detail||e.response?.data?.email?.[0]||"오류가 발생했습니다"))}finally{h(!1)}}};return(0,t.jsxs)("div",{style:{minHeight:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:"linear-gradient(135deg, var(--pri) 0%, var(--pri2) 100%)",padding:"var(--spacing-xl)"},className:"jsx-b85f33e5d07067d8",children:[(0,t.jsxs)("div",{style:{width:"100%",maxWidth:600,padding:"var(--spacing-4xl)",backgroundColor:"var(--card-bg)"},className:"jsx-b85f33e5d07067d8 card",children:[(0,t.jsxs)("div",{style:{textAlign:"center",marginBottom:"var(--spacing-3xl)"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("div",{style:{fontSize:64,marginBottom:"var(--spacing-lg)"},className:"jsx-b85f33e5d07067d8",children:"\uD83D\uDCAA"}),t.jsx("h1",{style:{margin:0,fontSize:"28px",fontWeight:700,marginBottom:"var(--spacing-xs)",color:"var(--text)"},className:"jsx-b85f33e5d07067d8",children:"펌피 회원 신청"}),t.jsx("p",{style:{margin:0,color:"var(--text-sub)",fontSize:"15px"},className:"jsx-b85f33e5d07067d8",children:"체육관 회원 등록을 시작합니다"})]}),t.jsx("div",{style:{display:"flex",justifyContent:"space-between",marginBottom:"var(--spacing-3xl)",position:"relative"},className:"jsx-b85f33e5d07067d8",children:[1,2,3].map(e=>(0,t.jsxs)("div",{style:{flex:1,display:"flex",flexDirection:"column",alignItems:"center",position:"relative"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("div",{style:{width:"40px",height:"40px",borderRadius:"50%",background:s>=e?"linear-gradient(135deg, var(--pri) 0%, var(--pri2) 100%)":"#e0e0e0",color:"white",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"18px",fontWeight:700,marginBottom:"8px",zIndex:2},className:"jsx-b85f33e5d07067d8",children:e}),(0,t.jsxs)("div",{style:{fontSize:"12px",fontWeight:600,color:s>=e?"var(--pri)":"#999",textAlign:"center"},className:"jsx-b85f33e5d07067d8",children:[1===e&&"기본 정보",2===e&&"상세 정보",3===e&&"약관 동의"]}),e<3&&t.jsx("div",{style:{position:"absolute",top:"20px",left:"50%",width:"100%",height:"3px",background:s>e?"var(--pri)":"#e0e0e0",zIndex:1},className:"jsx-b85f33e5d07067d8"})]},e))}),(0,t.jsxs)("form",{onSubmit:C,style:{display:"grid",gap:"var(--spacing-lg)"},className:"jsx-b85f33e5d07067d8",children:[1===s&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 2fr",gap:"var(--spacing-md)"},className:"jsx-b85f33e5d07067d8",children:[(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"성 *"}),t.jsx("input",{type:"text",value:r.last_name,onChange:e=>b("last_name",e.target.value),required:!0,placeholder:"홍",className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"이름 *"}),t.jsx("input",{type:"text",value:r.first_name,onChange:e=>b("first_name",e.target.value),required:!0,placeholder:"길동",className:"jsx-b85f33e5d07067d8"})]})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"전화번호 *"}),t.jsx("input",{type:"tel",value:r.phone,onChange:e=>b("phone",e.target.value),required:!0,placeholder:"010-1234-5678",className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"이메일 *"}),t.jsx("input",{type:"email",value:r.email,onChange:e=>b("email",e.target.value),required:!0,placeholder:"example@email.com",className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"비밀번호 * (최소 6자)"}),t.jsx("input",{type:"password",value:r.password,onChange:e=>b("password",e.target.value),required:!0,minLength:6,placeholder:"••••••",className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"비밀번호 확인 *"}),t.jsx("input",{type:"password",value:r.password_confirm,onChange:e=>b("password_confirm",e.target.value),required:!0,placeholder:"••••••",className:"jsx-b85f33e5d07067d8"})]}),t.jsx("button",{type:"button",onClick:N,style:{marginTop:"var(--spacing-md)"},className:"jsx-b85f33e5d07067d8 btn btn-primary w-full",children:"다음 단계 →"})]}),2===s&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"생년월일 *"}),t.jsx("input",{type:"date",value:r.birth_date,onChange:e=>b("birth_date",e.target.value),required:!0,className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"성별 *"}),(0,t.jsxs)("select",{value:r.gender,onChange:e=>b("gender",e.target.value),required:!0,style:{width:"100%",padding:"12px",borderRadius:"8px",border:"1px solid #ddd",fontSize:"15px"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("option",{value:"",className:"jsx-b85f33e5d07067d8",children:"선택하세요"}),t.jsx("option",{value:"남",className:"jsx-b85f33e5d07067d8",children:"남성"}),t.jsx("option",{value:"여",className:"jsx-b85f33e5d07067d8",children:"여성"}),t.jsx("option",{value:"기타",className:"jsx-b85f33e5d07067d8",children:"기타"})]})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"주소"}),t.jsx("input",{type:"text",value:r.address,onChange:e=>b("address",e.target.value),placeholder:"서울시 강남구...",className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"2fr 1fr",gap:"var(--spacing-md)"},className:"jsx-b85f33e5d07067d8",children:[(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"긴급 연락처"}),t.jsx("input",{type:"tel",value:r.emergency_contact,onChange:e=>b("emergency_contact",e.target.value),placeholder:"010-9876-5432",className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"관계"}),t.jsx("input",{type:"text",value:r.emergency_contact_relation,onChange:e=>b("emergency_contact_relation",e.target.value),placeholder:"부모, 배우자 등",className:"jsx-b85f33e5d07067d8"})]})]}),(0,t.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:"var(--spacing-md)"},className:"jsx-b85f33e5d07067d8",children:[(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"신장 (cm)"}),t.jsx("input",{type:"number",value:r.height,onChange:e=>b("height",e.target.value),placeholder:"175",className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"체중 (kg)"}),t.jsx("input",{type:"number",value:r.weight,onChange:e=>b("weight",e.target.value),placeholder:"70",className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"혈액형"}),(0,t.jsxs)("select",{value:r.blood_type,onChange:e=>b("blood_type",e.target.value),style:{width:"100%",padding:"12px",borderRadius:"8px",border:"1px solid #ddd",fontSize:"15px"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("option",{value:"",className:"jsx-b85f33e5d07067d8",children:"선택"}),t.jsx("option",{value:"A",className:"jsx-b85f33e5d07067d8",children:"A형"}),t.jsx("option",{value:"B",className:"jsx-b85f33e5d07067d8",children:"B형"}),t.jsx("option",{value:"O",className:"jsx-b85f33e5d07067d8",children:"O형"}),t.jsx("option",{value:"AB",className:"jsx-b85f33e5d07067d8",children:"AB형"}),t.jsx("option",{value:"RH-",className:"jsx-b85f33e5d07067d8",children:"RH-"})]})]})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"현재 레벨"}),(0,t.jsxs)("select",{value:r.current_level,onChange:e=>b("current_level",e.target.value),style:{width:"100%",padding:"12px",borderRadius:"8px",border:"1px solid #ddd",fontSize:"15px"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("option",{value:"초보",className:"jsx-b85f33e5d07067d8",children:"초보"}),t.jsx("option",{value:"중급",className:"jsx-b85f33e5d07067d8",children:"중급"}),t.jsx("option",{value:"고급",className:"jsx-b85f33e5d07067d8",children:"고급"}),t.jsx("option",{value:"1단",className:"jsx-b85f33e5d07067d8",children:"1단"}),t.jsx("option",{value:"2단",className:"jsx-b85f33e5d07067d8",children:"2단"}),t.jsx("option",{value:"3단",className:"jsx-b85f33e5d07067d8",children:"3단"})]})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"연령대"}),(0,t.jsxs)("select",{value:r.age_group,onChange:e=>b("age_group",e.target.value),style:{width:"100%",padding:"12px",borderRadius:"8px",border:"1px solid #ddd",fontSize:"15px"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("option",{value:"유치부",className:"jsx-b85f33e5d07067d8",children:"유치부"}),t.jsx("option",{value:"초등부",className:"jsx-b85f33e5d07067d8",children:"초등부"}),t.jsx("option",{value:"중등부",className:"jsx-b85f33e5d07067d8",children:"중등부"}),t.jsx("option",{value:"고등부",className:"jsx-b85f33e5d07067d8",children:"고등부"}),t.jsx("option",{value:"대학부",className:"jsx-b85f33e5d07067d8",children:"대학부"}),t.jsx("option",{value:"일반부",className:"jsx-b85f33e5d07067d8",children:"일반부"})]})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"건강 특이사항"}),t.jsx("textarea",{value:r.medical_notes,onChange:e=>b("medical_notes",e.target.value),placeholder:"건강상 특이사항이 있으면 적어주세요",rows:3,className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{className:"jsx-b85f33e5d07067d8",children:[t.jsx("label",{className:"jsx-b85f33e5d07067d8",children:"특이사항 / 문의사항"}),t.jsx("textarea",{value:r.notes,onChange:e=>b("notes",e.target.value),placeholder:"기타 문의사항이 있으시면 적어주세요",rows:3,className:"jsx-b85f33e5d07067d8"})]}),(0,t.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"var(--spacing-md)",marginTop:"var(--spacing-md)"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("button",{type:"button",onClick:_,style:{background:"#f5f5f5",color:"#666"},className:"jsx-b85f33e5d07067d8 btn",children:"← 이전"}),t.jsx("button",{type:"button",onClick:N,className:"jsx-b85f33e5d07067d8 btn btn-primary",children:"다음 단계 →"})]})]}),3===s&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{style:{background:"var(--hover-bg)",padding:"var(--spacing-lg)",borderRadius:"12px"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("div",{style:{marginBottom:"var(--spacing-md)"},className:"jsx-b85f33e5d07067d8",children:(0,t.jsxs)("label",{style:{display:"flex",alignItems:"center",cursor:"pointer",fontSize:"15px",fontWeight:600},className:"jsx-b85f33e5d07067d8",children:[t.jsx("input",{type:"checkbox",checked:p.terms&&p.privacy,onChange:e=>{let s=e.target.checked;m({terms:s,privacy:s,marketing:s})},style:{width:"20px",height:"20px",marginRight:"10px",cursor:"pointer"},className:"jsx-b85f33e5d07067d8"}),t.jsx("span",{style:{color:"var(--text-primary)"},className:"jsx-b85f33e5d07067d8",children:"전체 동의"})]})}),(0,t.jsxs)("div",{style:{borderTop:"1px solid var(--border-color)",paddingTop:"var(--spacing-md)",display:"grid",gap:"var(--spacing-sm)"},className:"jsx-b85f33e5d07067d8",children:[(0,t.jsxs)("label",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",cursor:"pointer",fontSize:"14px"},className:"jsx-b85f33e5d07067d8",children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("input",{type:"checkbox",checked:p.terms,onChange:e=>m({...p,terms:e.target.checked}),style:{width:"18px",height:"18px",marginRight:"10px",cursor:"pointer"},className:"jsx-b85f33e5d07067d8"}),(0,t.jsxs)("span",{style:{color:"var(--text-primary)"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("span",{style:{color:"var(--primary-color)",fontWeight:600},className:"jsx-b85f33e5d07067d8",children:"[필수]"})," 이용 약관 동의"]})]}),t.jsx("button",{type:"button",onClick:()=>j("terms"),style:{background:"none",border:"none",color:"var(--text-secondary)",textDecoration:"underline",cursor:"pointer",fontSize:"13px"},className:"jsx-b85f33e5d07067d8",children:"보기"})]}),(0,t.jsxs)("label",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",cursor:"pointer",fontSize:"14px"},className:"jsx-b85f33e5d07067d8",children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("input",{type:"checkbox",checked:p.privacy,onChange:e=>m({...p,privacy:e.target.checked}),style:{width:"18px",height:"18px",marginRight:"10px",cursor:"pointer"},className:"jsx-b85f33e5d07067d8"}),(0,t.jsxs)("span",{style:{color:"var(--text-primary)"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("span",{style:{color:"var(--primary-color)",fontWeight:600},className:"jsx-b85f33e5d07067d8",children:"[필수]"})," 개인정보 처리방침 동의"]})]}),t.jsx("button",{type:"button",onClick:()=>j("privacy"),style:{background:"none",border:"none",color:"var(--text-secondary)",textDecoration:"underline",cursor:"pointer",fontSize:"13px"},className:"jsx-b85f33e5d07067d8",children:"보기"})]}),(0,t.jsxs)("label",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",cursor:"pointer",fontSize:"14px"},className:"jsx-b85f33e5d07067d8",children:[(0,t.jsxs)("div",{style:{display:"flex",alignItems:"center"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("input",{type:"checkbox",checked:p.marketing,onChange:e=>m({...p,marketing:e.target.checked}),style:{width:"18px",height:"18px",marginRight:"10px",cursor:"pointer"},className:"jsx-b85f33e5d07067d8"}),(0,t.jsxs)("span",{style:{color:"var(--text-secondary)"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("span",{style:{color:"var(--text-tertiary)",fontWeight:600},className:"jsx-b85f33e5d07067d8",children:"[선택]"})," 마케팅 정보 수신 및 활용 동의"]})]}),t.jsx("button",{type:"button",onClick:()=>j("marketing"),style:{background:"none",border:"none",color:"var(--text-secondary)",textDecoration:"underline",cursor:"pointer",fontSize:"13px"},className:"jsx-b85f33e5d07067d8",children:"보기"})]})]})]}),(0,t.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"var(--spacing-md)",marginTop:"var(--spacing-md)"},className:"jsx-b85f33e5d07067d8",children:[t.jsx("button",{type:"button",onClick:_,style:{background:"#f5f5f5",color:"#666"},className:"jsx-b85f33e5d07067d8 btn",children:"← 이전"}),t.jsx("button",{type:"submit",disabled:u,className:"jsx-b85f33e5d07067d8 btn btn-primary",children:u?"처리 중...":"회원 신청하기"})]})]}),t.jsx("div",{style:{textAlign:"center",marginTop:"var(--spacing-md)"},className:"jsx-b85f33e5d07067d8",children:t.jsx("a",{href:"/auth/login",style:{color:"var(--pri)",fontSize:"14px",fontWeight:600},className:"jsx-b85f33e5d07067d8",children:"이미 회원이신가요? 로그인"})})]})]}),g&&t.jsx(o,{isOpen:!0,onClose:()=>j(null),type:g}),t.jsx(d(),{id:"b85f33e5d07067d8",children:"@media(max-width:768px){div.jsx-b85f33e5d07067d8:first-child{padding:var(--spacing-md)!important}.card.jsx-b85f33e5d07067d8{padding:var(--spacing-2xl)!important}h1.jsx-b85f33e5d07067d8{font-size:24px!important}}"})]})}},6824:(e,s,a)=>{"use strict";a.d(s,{kG:()=>t});let t=()=>"/api"},9791:(e,s,a)=>{"use strict";a.r(s),a.d(s,{$$typeof:()=>l,__esModule:()=>d,default:()=>n});var t=a(8570);let r=(0,t.createProxy)(String.raw`C:\Users\guddn\Downloads\COCO\gym_web\app\signup\page.tsx`),{__esModule:d,$$typeof:l}=r;r.default;let n=(0,t.createProxy)(String.raw`C:\Users\guddn\Downloads\COCO\gym_web\app\signup\page.tsx#default`)},7817:()=>{}};var s=require("../../webpack-runtime.js");s.C(e);var a=e=>s(s.s=e),t=s.X(0,[804,4099,6382],()=>a(3531));module.exports=t})();