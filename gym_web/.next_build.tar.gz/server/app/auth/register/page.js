(()=>{var e={};e.id=454,e.ids=[454],e.modules={7849:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external")},2934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},5403:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external")},4580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},4749:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external")},5869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},9491:e=>{"use strict";e.exports=require("assert")},6113:e=>{"use strict";e.exports=require("crypto")},2361:e=>{"use strict";e.exports=require("events")},7147:e=>{"use strict";e.exports=require("fs")},3685:e=>{"use strict";e.exports=require("http")},5687:e=>{"use strict";e.exports=require("https")},2037:e=>{"use strict";e.exports=require("os")},1017:e=>{"use strict";e.exports=require("path")},2781:e=>{"use strict";e.exports=require("stream")},6224:e=>{"use strict";e.exports=require("tty")},7310:e=>{"use strict";e.exports=require("url")},3837:e=>{"use strict";e.exports=require("util")},9796:e=>{"use strict";e.exports=require("zlib")},1807:(e,t,r)=>{"use strict";r.r(t),r.d(t,{GlobalError:()=>s.a,__next_app__:()=>c,originalPathname:()=>x,pages:()=>p,routeModule:()=>u,tree:()=>d}),r(3374),r(1506),r(5866);var i=r(3191),o=r(8716),n=r(7922),s=r.n(n),l=r(5231),a={};for(let e in l)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(a[e]=()=>l[e]);r.d(t,a);let d=["",{children:["auth",{children:["register",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(r.bind(r,3374)),"C:\\Users\\guddn\\Downloads\\COCO\\gym_web\\app\\auth\\register\\page.tsx"]}]},{}]},{}]},{layout:[()=>Promise.resolve().then(r.bind(r,1506)),"C:\\Users\\guddn\\Downloads\\COCO\\gym_web\\app\\layout.tsx"],"not-found":[()=>Promise.resolve().then(r.t.bind(r,5866,23)),"next/dist/client/components/not-found-error"]}],p=["C:\\Users\\guddn\\Downloads\\COCO\\gym_web\\app\\auth\\register\\page.tsx"],x="/auth/register/page",c={require:r,loadChunk:()=>Promise.resolve()},u=new i.AppPageRouteModule({definition:{kind:o.x.APP_PAGE,page:"/auth/register/page",pathname:"/auth/register",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},6176:(e,t,r)=>{Promise.resolve().then(r.bind(r,353))},353:(e,t,r)=>{"use strict";r.r(t),r.d(t,{default:()=>p});var i=r(326),o=r(7577),n=r(5047),s=r(4099),l=r(6824),a=r(434);let d={terms:{title:"이용약관",content:`
제1조 (목적)
본 약관은 펌피(이하 "회사")가 제공하는 피트니스 서비스(이하 "서비스")의 이용과 관련하여 회사와 회원 간의 권리, 의무 및 책임사항, 기타 필요한 사항을 규정함을 목적으로 합니다.

제2조 (정의)
1. "서비스"란 회사가 제공하는 피트니스 센터 이용 및 관련 부가 서비스를 의미합니다.
2. "회원"이란 본 약관에 동의하고 회사와 서비스 이용계약을 체결한 자를 의미합니다.
3. "회원권"이란 회원이 서비스를 이용할 수 있는 권리를 의미합니다.

제3조 (약관의 효력 및 변경)
1. 본 약관은 회원이 약관에 동의하고 회사가 정한 절차에 따라 회원 가입을 완료함으로써 효력이 발생합니다.
2. 회사는 필요한 경우 관련 법령을 위배하지 않는 범위에서 본 약관을 변경할 수 있습니다.
3. 약관이 변경되는 경우 회사는 변경 사항을 시행일로부터 최소 7일 전에 공지합니다.

제4조 (서비스의 제공 및 변경)
1. 회사는 다음과 같은 서비스를 제공합니다:
   - 피트니스 시설 이용
   - 운동 프로그램 제공
   - 트레이너 상담 서비스
   - 기타 부대 서비스
2. 회사는 운영상 필요한 경우 서비스의 내용을 변경할 수 있습니다.

제5조 (회원의 의무)
1. 회원은 서비스 이용 시 다음 사항을 준수해야 합니다:
   - 시설 이용 규칙 준수
   - 타 회원에 대한 배려
   - 안전 수칙 준수
2. 회원은 본인의 건강 상태에 대해 사실대로 고지해야 합니다.

제6조 (환불 및 해지)
1. 회원은 계약 체결 후 7일 이내 서비스를 이용하지 않은 경우 계약을 해지하고 전액 환불받을 수 있습니다.
2. 서비스 이용 후 해지 시 이용 일수에 비례하여 환불됩니다.

제7조 (면책조항)
1. 회사는 천재지변 또는 이에 준하는 불가항력으로 인해 서비스를 제공할 수 없는 경우 책임이 면제됩니다.
2. 회원의 귀책사유로 인한 사고에 대해 회사는 책임을 지지 않습니다.

제8조 (분쟁 해결)
본 약관과 관련된 분쟁은 대한민국 법률에 따라 해결하며, 관할 법원은 회사의 소재지 법원으로 합니다.

부칙
본 약관은 2025년 1월 1일부터 시행됩니다.
    `},privacy:{title:"개인정보 처리방침",content:`
펌피(이하 "회사")는 「개인정보 보호법」 제30조에 따라 정보주체의 개인정보를 보호하고 이와 관련한 고충을 신속하고 원활하게 처리할 수 있도록 다음과 같이 개인정보 처리방침을 수립\xb7공개합니다.

제1조 (개인정보의 처리 목적)
회사는 다음의 목적을 위하여 개인정보를 처리합니다:
1. 회원 가입 및 관리
2. 서비스 제공
3. 고충 처리
4. 마케팅 및 광고 활용 (선택적 동의)

제2조 (처리하는 개인정보의 항목)
회사는 다음의 개인정보 항목을 처리하고 있습니다:
1. 필수항목: 이름, 이메일, 전화번호, 생년월일
2. 선택항목: 주소, 긴급연락처
3. 서비스 이용 과정에서 자동 수집: 접속 IP, 쿠키, 서비스 이용 기록

제3조 (개인정보의 처리 및 보유 기간)
1. 회사는 법령에 따른 개인정보 보유\xb7이용기간 또는 정보주체로부터 개인정보를 수집 시 동의받은 개인정보 보유\xb7이용기간 내에서 개인정보를 처리\xb7보유합니다.
2. 회원 탈퇴 시 개인정보는 즉시 파기됩니다. 단, 관련 법령에 따라 보존이 필요한 경우 일정 기간 보관 후 파기합니다.

제4조 (개인정보의 제3자 제공)
회사는 원칙적으로 정보주체의 개인정보를 제3자에게 제공하지 않습니다. 다만, 다음의 경우는 예외로 합니다:
1. 정보주체가 사전에 동의한 경우
2. 법령의 규정에 의거하거나, 수사 목적으로 법령에 정해진 절차와 방법에 따라 수사기관의 요구가 있는 경우

제5조 (개인정보의 파기)
회사는 개인정보 보유기간의 경과, 처리목적 달성 등 개인정보가 불필요하게 되었을 때는 지체없이 해당 개인정보를 파기합니다.

제6조 (정보주체의 권리\xb7의무 및 행사방법)
정보주체는 회사에 대해 언제든지 다음 각 호의 개인정보 보호 관련 권리를 행사할 수 있습니다:
1. 개인정보 열람 요구
2. 오류 등이 있을 경우 정정 요구
3. 삭제 요구
4. 처리정지 요구

제7조 (개인정보 보호책임자)
회사는 개인정보 처리에 관한 업무를 총괄해서 책임지고, 개인정보 처리와 관련한 정보주체의 불만처리를 위하여 아래와 같이 개인정보 보호책임자를 지정하고 있습니다.
- 이메일: privacy@pumpy.com
- 전화번호: 02-1234-5678

제8조 (개인정보 처리방침 변경)
이 개인정보처리방침은 시행일로부터 적용되며, 법령 및 방침에 따른 변경내용의 추가, 삭제 및 정정이 있는 경우에는 변경사항의 시행 7일 전부터 공지사항을 통하여 고지할 것입니다.

부칙
본 방침은 2025년 1월 1일부터 시행됩니다.
    `},marketing:{title:"마케팅 정보 수신 동의",content:`
펌피(이하 "회사")는 회원님께 다양한 혜택과 이벤트 정보를 제공하기 위해 마케팅 정보 수신 동의를 받고 있습니다.

제1조 (수집 목적)
회사는 다음의 목적으로 마케팅 정보를 발송합니다:
1. 신규 서비스 안내
2. 이벤트 및 프로모션 정보 제공
3. 맞춤형 서비스 추천
4. 회원권 갱신 안내

제2조 (발송 방법)
마케팅 정보는 다음의 방법으로 발송됩니다:
1. 이메일
2. SMS/MMS
3. 앱 푸시 알림
4. 우편물 (선택 시)

제3조 (수신 동의 철회)
1. 회원은 언제든지 마케팅 정보 수신을 거부할 수 있습니다.
2. 수신 거부 방법:
   - 앱 내 설정 > 알림 설정
   - 이메일 하단의 '수신거부' 링크 클릭
   - 고객센터 문의 (02-1234-5678)

제4조 (동의 거부 권리 및 불이익)
1. 회원은 마케팅 정보 수신에 동의하지 않을 권리가 있습니다.
2. 마케팅 정보 수신에 동의하지 않아도 서비스 이용에는 제한이 없습니다.
3. 단, 프로모션 정보를 받지 못할 수 있습니다.

제5조 (개인정보 제공)
마케팅 목적으로 수집된 개인정보는 제3자에게 제공되지 않습니다.

제6조 (사진 및 영상 촬영 동의)
1. 회사는 시설 홍보 및 SNS 콘텐츠 제작을 위해 사진 및 영상을 촬영할 수 있습니다.
2. 촬영된 사진 및 영상은 다음의 용도로 사용됩니다:
   - 회사 홈페이지 및 SNS 게시
   - 온라인/오프라인 광고
   - 홍보 자료 제작
3. 회원은 언제든지 사진 및 영상 사용 동의를 철회할 수 있습니다.

부칙
본 동의서는 2025년 1월 1일부터 시행됩니다.
    `}};function p(){let e=(0,n.useRouter)(),[t,r]=(0,o.useState)({email:"",password:"",passwordConfirm:"",firstName:"",lastName:"",phone:""}),[p,x]=(0,o.useState)(!1),[c,u]=(0,o.useState)(""),[g,h]=(0,o.useState)(!1),[m,y]=(0,o.useState)(!1),[b,f]=(0,o.useState)({all:!1,terms:!1,privacy:!1,marketing:!1}),[j,v]=(0,o.useState)(null),[C,w]=(0,o.useState)({code:"",sent:!1,verified:!1,serverCode:"",timer:180}),[S,k]=(0,o.useState)(null),D=e=>{f({all:e,terms:e,privacy:e,marketing:e})},z=(e,t)=>{let r={...b,[e]:t};r.all=r.terms&&r.privacy&&r.marketing,f(r)},_=async r=>{if(r.preventDefault(),u(""),!t.email||!t.password||!t.firstName||!t.lastName||!t.phone){u("모든 필수 항목을 입력해주세요.");return}if(t.password!==t.passwordConfirm){u("비밀번호가 일치하지 않습니다.");return}if(t.password.length<8){u("비밀번호는 8자 이상이어야 합니다.");return}if(!b.terms||!b.privacy){u("필수 약관에 동의해주세요.");return}x(!0);try{let r=(0,l.kG)();await s.Z.post(`${r}/auth/register/`,{email:t.email,password:t.password,password_confirm:t.passwordConfirm,first_name:t.firstName,last_name:t.lastName,phone:t.phone,phone_verified:!0,terms_agreed:b.terms,privacy_agreed:b.privacy,marketing_agreed:b.marketing},{timeout:1e4}),alert("회원가입이 완료되었습니다! 로그인 해주세요."),e.push("/auth/login")}catch(e){console.error("회원가입 실패:",e),e.response?.data?.error?u(e.response.data.error):u("회원가입 중 오류가 발생했습니다.")}finally{x(!1)}};return(0,i.jsxs)("div",{style:{minHeight:"100vh",background:"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",padding:"40px 24px",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'},children:[(0,i.jsxs)("div",{style:{maxWidth:"480px",margin:"0 auto"},children:[(0,i.jsxs)("div",{style:{textAlign:"center",marginBottom:"32px"},children:[i.jsx("div",{style:{fontSize:"48px",marginBottom:"12px"},children:"\uD83D\uDCAA"}),i.jsx("h1",{style:{fontSize:"32px",fontWeight:"900",color:"white",margin:"0 0 8px 0"},children:"회원가입"}),i.jsx("p",{style:{fontSize:"14px",color:"rgba(255,255,255,0.9)",margin:0},children:"펌피와 함께 건강한 삶을 시작하세요"})]}),i.jsx("div",{style:{background:"white",borderRadius:"24px",padding:"32px 24px",boxShadow:"0 20px 60px rgba(0,0,0,0.3)"},children:(0,i.jsxs)("form",{onSubmit:_,children:[(0,i.jsxs)("div",{style:{marginBottom:"20px"},children:[i.jsx("label",{style:{display:"block",fontSize:"14px",fontWeight:"600",color:"#666",marginBottom:"8px"},children:"이메일 *"}),i.jsx("input",{type:"email",value:t.email,onChange:e=>r({...t,email:e.target.value}),placeholder:"example@email.com",disabled:p,style:{width:"100%",height:"48px",padding:"0 16px",fontSize:"15px",border:"2px solid #e0e0e0",borderRadius:"12px",outline:"none",fontFamily:"inherit"},onFocus:e=>e.target.style.borderColor="#667eea",onBlur:e=>e.target.style.borderColor="#e0e0e0"})]}),(0,i.jsxs)("div",{style:{marginBottom:"20px"},children:[i.jsx("label",{style:{display:"block",fontSize:"14px",fontWeight:"600",color:"#666",marginBottom:"8px"},children:"비밀번호 * (8자 이상)"}),(0,i.jsxs)("div",{style:{position:"relative"},children:[i.jsx("input",{type:g?"text":"password",value:t.password,onChange:e=>r({...t,password:e.target.value}),placeholder:"비밀번호를 입력하세요",disabled:p,style:{width:"100%",height:"48px",padding:"0 48px 0 16px",fontSize:"15px",border:"2px solid #e0e0e0",borderRadius:"12px",outline:"none",fontFamily:"inherit"},onFocus:e=>e.target.style.borderColor="#667eea",onBlur:e=>e.target.style.borderColor="#e0e0e0"}),i.jsx("button",{type:"button",onClick:()=>h(!g),style:{position:"absolute",right:"16px",top:"50%",transform:"translateY(-50%)",background:"none",border:"none",fontSize:"18px",cursor:"pointer"},children:g?"\uD83D\uDC41️":"\uD83D\uDC41️‍\uD83D\uDDE8️"})]})]}),(0,i.jsxs)("div",{style:{marginBottom:"20px"},children:[i.jsx("label",{style:{display:"block",fontSize:"14px",fontWeight:"600",color:"#666",marginBottom:"8px"},children:"비밀번호 확인 *"}),(0,i.jsxs)("div",{style:{position:"relative"},children:[i.jsx("input",{type:m?"text":"password",value:t.passwordConfirm,onChange:e=>r({...t,passwordConfirm:e.target.value}),placeholder:"비밀번호를 다시 입력하세요",disabled:p,style:{width:"100%",height:"48px",padding:"0 48px 0 16px",fontSize:"15px",border:"2px solid #e0e0e0",borderRadius:"12px",outline:"none",fontFamily:"inherit"},onFocus:e=>e.target.style.borderColor="#667eea",onBlur:e=>e.target.style.borderColor="#e0e0e0"}),i.jsx("button",{type:"button",onClick:()=>y(!m),style:{position:"absolute",right:"16px",top:"50%",transform:"translateY(-50%)",background:"none",border:"none",fontSize:"18px",cursor:"pointer"},children:m?"\uD83D\uDC41️":"\uD83D\uDC41️‍\uD83D\uDDE8️"})]})]}),(0,i.jsxs)("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"12px",marginBottom:"20px"},children:[(0,i.jsxs)("div",{children:[i.jsx("label",{style:{display:"block",fontSize:"14px",fontWeight:"600",color:"#666",marginBottom:"8px"},children:"성 *"}),i.jsx("input",{type:"text",value:t.lastName,onChange:e=>r({...t,lastName:e.target.value}),placeholder:"김",disabled:p,style:{width:"100%",height:"48px",padding:"0 16px",fontSize:"15px",border:"2px solid #e0e0e0",borderRadius:"12px",outline:"none",fontFamily:"inherit"},onFocus:e=>e.target.style.borderColor="#667eea",onBlur:e=>e.target.style.borderColor="#e0e0e0"})]}),(0,i.jsxs)("div",{children:[i.jsx("label",{style:{display:"block",fontSize:"14px",fontWeight:"600",color:"#666",marginBottom:"8px"},children:"이름 *"}),i.jsx("input",{type:"text",value:t.firstName,onChange:e=>r({...t,firstName:e.target.value}),placeholder:"철수",disabled:p,style:{width:"100%",height:"48px",padding:"0 16px",fontSize:"15px",border:"2px solid #e0e0e0",borderRadius:"12px",outline:"none",fontFamily:"inherit"},onFocus:e=>e.target.style.borderColor="#667eea",onBlur:e=>e.target.style.borderColor="#e0e0e0"})]})]}),(0,i.jsxs)("div",{style:{marginBottom:"24px"},children:[i.jsx("label",{style:{display:"block",fontSize:"14px",fontWeight:"600",color:"#666",marginBottom:"8px"},children:"전화번호 * (- 없이 입력)"}),i.jsx("input",{type:"tel",value:t.phone,onChange:e=>r({...t,phone:e.target.value.replace(/[^0-9]/g,"")}),placeholder:"01012345678",disabled:p,style:{width:"100%",height:"48px",padding:"0 16px",fontSize:"15px",border:"2px solid #e0e0e0",borderRadius:"12px",outline:"none",fontFamily:"inherit",boxSizing:"border-box"},onFocus:e=>e.target.style.borderColor="#667eea",onBlur:e=>e.target.style.borderColor="#e0e0e0"}),i.jsx("div",{style:{fontSize:"12px",color:"#10b981",marginTop:"6px",fontWeight:"500"},children:"\uD83D\uDCF1 인증 없이 바로 가입 가능합니다"}),!1]}),(0,i.jsxs)("div",{style:{background:"#f9f9f9",borderRadius:"12px",padding:"20px",marginBottom:"24px"},children:[i.jsx("div",{style:{marginBottom:"16px"},children:(0,i.jsxs)("label",{style:{display:"flex",alignItems:"center",cursor:"pointer",fontSize:"16px",fontWeight:"700"},children:[i.jsx("input",{type:"checkbox",checked:b.all,onChange:e=>D(e.target.checked),style:{width:"20px",height:"20px",marginRight:"10px",cursor:"pointer"}}),"전체 동의"]})}),(0,i.jsxs)("div",{style:{paddingLeft:"30px",display:"flex",flexDirection:"column",gap:"12px"},children:[(0,i.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between"},children:[(0,i.jsxs)("label",{style:{display:"flex",alignItems:"center",cursor:"pointer",fontSize:"14px"},children:[i.jsx("input",{type:"checkbox",checked:b.terms,onChange:e=>z("terms",e.target.checked),style:{width:"18px",height:"18px",marginRight:"8px",cursor:"pointer"}}),i.jsx("span",{children:"[필수] 이용약관 동의"})]}),i.jsx("button",{type:"button",onClick:()=>v("terms"),style:{background:"none",border:"none",color:"#667eea",fontSize:"13px",fontWeight:"600",cursor:"pointer",textDecoration:"underline"},children:"보기"})]}),(0,i.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between"},children:[(0,i.jsxs)("label",{style:{display:"flex",alignItems:"center",cursor:"pointer",fontSize:"14px"},children:[i.jsx("input",{type:"checkbox",checked:b.privacy,onChange:e=>z("privacy",e.target.checked),style:{width:"18px",height:"18px",marginRight:"8px",cursor:"pointer"}}),i.jsx("span",{children:"[필수] 개인정보 처리방침 동의"})]}),i.jsx("button",{type:"button",onClick:()=>v("privacy"),style:{background:"none",border:"none",color:"#667eea",fontSize:"13px",fontWeight:"600",cursor:"pointer",textDecoration:"underline"},children:"보기"})]}),(0,i.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between"},children:[(0,i.jsxs)("label",{style:{display:"flex",alignItems:"center",cursor:"pointer",fontSize:"14px"},children:[i.jsx("input",{type:"checkbox",checked:b.marketing,onChange:e=>z("marketing",e.target.checked),style:{width:"18px",height:"18px",marginRight:"8px",cursor:"pointer"}}),i.jsx("span",{children:"[선택] 마케팅 정보 수신 동의"})]}),i.jsx("button",{type:"button",onClick:()=>v("marketing"),style:{background:"none",border:"none",color:"#667eea",fontSize:"13px",fontWeight:"600",cursor:"pointer",textDecoration:"underline"},children:"보기"})]})]})]}),c&&i.jsx("div",{style:{background:"#fee",border:"2px solid #fcc",borderRadius:"12px",padding:"14px",marginBottom:"20px",fontSize:"14px",color:"#c33",fontWeight:"600",textAlign:"center"},children:c}),i.jsx("button",{type:"submit",disabled:p,style:{width:"100%",height:"56px",background:p?"#ccc":"linear-gradient(135deg, #667eea 0%, #764ba2 100%)",border:"none",borderRadius:"12px",color:"white",fontSize:"18px",fontWeight:"700",cursor:p?"not-allowed":"pointer",boxShadow:p?"none":"0 4px 12px rgba(102, 126, 234, 0.4)",marginBottom:"16px"},children:p?"가입 중...":"가입하기"}),(0,i.jsxs)("div",{style:{textAlign:"center"},children:[i.jsx("span",{style:{fontSize:"14px",color:"#666"},children:"이미 회원이신가요? "}),i.jsx(a.default,{href:"/auth/login",style:{fontSize:"14px",color:"#667eea",fontWeight:"700",textDecoration:"none"},children:"로그인"})]})]})})]}),j&&i.jsx("div",{onClick:()=>v(null),style:{position:"fixed",inset:0,background:"rgba(0,0,0,0.7)",display:"flex",alignItems:"center",justifyContent:"center",padding:"24px",zIndex:1e3},children:(0,i.jsxs)("div",{onClick:e=>e.stopPropagation(),style:{background:"white",borderRadius:"20px",maxWidth:"600px",width:"100%",maxHeight:"80vh",overflow:"hidden",display:"flex",flexDirection:"column"},children:[(0,i.jsxs)("div",{style:{padding:"24px",borderBottom:"1px solid #f0f0f0",display:"flex",justifyContent:"space-between",alignItems:"center"},children:[i.jsx("h3",{style:{margin:0,fontSize:"20px",fontWeight:"700"},children:d[j].title}),i.jsx("button",{onClick:()=>v(null),style:{background:"none",border:"none",fontSize:"24px",cursor:"pointer",padding:"4px"},children:"\xd7"})]}),i.jsx("div",{style:{padding:"24px",overflow:"auto",flex:1,fontSize:"14px",lineHeight:"1.8",color:"#333",whiteSpace:"pre-wrap"},children:d[j].content}),i.jsx("div",{style:{padding:"16px 24px",borderTop:"1px solid #f0f0f0"},children:i.jsx("button",{onClick:()=>v(null),style:{width:"100%",height:"48px",background:"#667eea",border:"none",borderRadius:"12px",color:"white",fontSize:"16px",fontWeight:"700",cursor:"pointer"},children:"확인"})})]})})]})}},6824:(e,t,r)=>{"use strict";r.d(t,{kG:()=>i});let i=()=>"http://3.27.28.175:8000/api"},3374:(e,t,r)=>{"use strict";r.r(t),r.d(t,{$$typeof:()=>s,__esModule:()=>n,default:()=>l});var i=r(8570);let o=(0,i.createProxy)(String.raw`C:\Users\guddn\Downloads\COCO\gym_web\app\auth\register\page.tsx`),{__esModule:n,$$typeof:s}=o;o.default;let l=(0,i.createProxy)(String.raw`C:\Users\guddn\Downloads\COCO\gym_web\app\auth\register\page.tsx#default`)}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),i=t.X(0,[804,99,434,382],()=>r(1807));module.exports=i})();